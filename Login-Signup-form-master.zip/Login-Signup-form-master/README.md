# Login form & Sign Up form full Code

[This](https://mehedi61.github.io/Login-Signup-form/login.html) is a [Login](https://mehedi61.github.io/Login-Signup-form/login.html) form and a [Sign up](https://mehedi61.github.io/Login-Signup-form/signup.html) form.  
Built with **HTML5** and **CSS3**. 

### Tasks

* Require the username and password on the **login** page.
* Require full name, email address, username and a password on the **sign up** page.
